#!/bin/bash
#SBATCH --job-name=CYI-4cn53
#SBATCH --output=slurm_%a.out
#SBATCH --time=48:00:00
#SBATCH --partition=warshel
#SBATCH --account=warshel_155
#SBATCH --mem-per-cpu=1GB
#SBATCH --nodes=1
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=1
#SBATCH --ntasks=32
#SBATCH --array=1

export OMP_NUM_THREADS=8
module purge
module load gcc/8.3.0 openmpi/4.0.2  gromacs

bash ./job6.sh > ./md.log
