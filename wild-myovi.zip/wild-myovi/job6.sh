mkdir conf0
cp after_em.gro 2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj1.gro jz4.itp vnl1.itp um0.mdp um0_npt.mdp conf0 
cd conf0
cp -r ../charmm36-jul2022.ff/ .
gmx_mpi grompp -f um0_npt.mdp -c traj1.gro -r traj1.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro 
gmx_mpi grompp -f um0.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um0.tpr -maxwarn 1
gmx_mpi mdrun -s um0.tpr -c after_um.gro 
cd ../
mkdir conf1
cp after_em.gro 2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj2.gro jz4.itp vnl1.itp um1.mdp um1_npt.mdp conf1
cd conf1
cp -r ../charmm36-jul2022.ff/ .
cp ../conf0/after_um.gro .
gmx_mpi grompp -f um1_npt.mdp -c traj2.gro -r traj2.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro 
gmx_mpi grompp -f um1.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um1.tpr -maxwarn 1
gmx_mpi mdrun -s um1.tpr -c after_um.gro 
cd ../
mkdir conf2
cp after_em.gro  2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj3.gro jz4.itp vnl1.itp um2.mdp um2_npt.mdp conf2
cd conf2
cp -r ../charmm36-jul2022.ff/ .
cp ../conf1/after_um.gro .
gmx_mpi grompp -f um2_npt.mdp -c traj3.gro -r traj3.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro 
gmx_mpi grompp -f um2.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um2.tpr -maxwarn 1
gmx_mpi mdrun -s um2.tpr -c after_um.gro
cd ../
mkdir conf3
cp after_em.gro  2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj4.gro jz4.itp vnl1.itp um3.mdp um3_npt.mdp conf3
cd conf3
cp -r ../charmm36-jul2022.ff/ .
cp ../conf2/after_um.gro .
gmx_mpi grompp -f um3_npt.mdp -c traj4.gro -r traj4.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro 
gmx_mpi grompp -f um3.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um3.tpr -maxwarn 1
gmx_mpi mdrun -s um3.tpr -c after_um.gro
cd ../
mkdir conf4
cp after_em.gro 2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj5.gro jz4.itp vnl1.itp um4.mdp um4_npt.mdp conf4
cd conf4
cp -r ../charmm36-jul2022.ff/ .
cp ../conf3/after_um.gro .
gmx_mpi grompp -f um4_npt.mdp -c traj5.gro -r traj5.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro 
gmx_mpi grompp -f um4.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um4.tpr -maxwarn 1
gmx_mpi mdrun -s um4.tpr -c after_um.gro 
cd ../
mkdir conf5
cp after_em.gro  2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj6.gro jz4.itp vnl1.itp um5.mdp um5_npt.mdp conf5
cd conf5
cp -r ../charmm36-jul2022.ff/ .
cp ../conf4/after_um.gro .
gmx_mpi grompp -f um5_npt.mdp -c traj6.gro -r traj6.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro
gmx_mpi grompp -f um5.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um5.tpr -maxwarn 1
gmx_mpi mdrun -s um5.tpr -c after_um.gro
cd ../
mkdir conf6
cp after_em.gro 2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj7.gro jz4.itp vnl1.itp um6.mdp um6_npt.mdp conf6
cd conf6
cp -r ../charmm36-jul2022.ff/ .
cp ../conf5/after_um.gro .
gmx_mpi grompp -f um6_npt.mdp -c traj7.gro -r traj7.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro
gmx_mpi grompp -f um6.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um6.tpr -maxwarn 1
gmx_mpi mdrun -s um6.tpr -c after_um.gro 
cd ../
mkdir conf7
cp after_em.gro 2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj8.gro jz4.itp vnl1.itp um7.mdp um7_npt.mdp conf7
cd conf7
cp -r ../charmm36-jul2022.ff/ .
cp ../conf6/after_um.gro .
gmx_mpi grompp -f um7_npt.mdp -c traj8.gro -r traj8.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro
gmx_mpi grompp -f um7.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um7.tpr -maxwarn 1
gmx_mpi mdrun -s um7.tpr -c after_um.gro
cd ../
mkdir conf8
cp after_em.gro 2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj9.gro jz4.itp vnl1.itp um8.mdp um8_npt.mdp conf8
cd conf8
cp -r ../charmm36-jul2022.ff/ .
cp ../conf7/after_um.gro .
gmx_mpi grompp -f um8_npt.mdp -c traj9.gro -r traj9.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro 
gmx_mpi grompp -f um8.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um8.tpr -maxwarn 1
gmx_mpi mdrun -s um8.tpr -c after_um.gro
cd ../
mkdir conf9
cp after_em.gro 2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj10.gro jz4.itp vnl1.itp um9.mdp um9_npt.mdp conf9
cd conf9
cp -r ../charmm36-jul2022.ff/ .
cp ../conf8/after_um.gro .
gmx_mpi grompp -f um9_npt.mdp -c traj10.gro -r traj10.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro
gmx_mpi grompp -f um9.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um9.tpr -maxwarn 1
gmx_mpi mdrun -s um9.tpr -c after_um.gro
cd ../
mkdir conf10
cp after_em.gro 2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj11.gro jz4.itp vnl1.itp um10.mdp um10_npt.mdp conf10
cd conf10
cp -r ../charmm36-jul2022.ff/ .
cp ../conf9/after_um.gro .
gmx_mpi grompp -f um10_npt.mdp -c traj11.gro -r traj11.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro 
gmx_mpi grompp -f um10.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um10.tpr -maxwarn 1
gmx_mpi mdrun -s um10.tpr -c after_um.gro 
cd ../
mkdir conf11
cp after_em.gro 2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj12.gro jz4.itp vnl1.itp um11.mdp um11_npt.mdp conf11
cd conf11
cp -r ../charmm36-jul2022.ff/ .
cp ../conf10/after_um.gro .
gmx_mpi grompp -f um11_npt.mdp -c traj12.gro -r traj12.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro 
gmx_mpi grompp -f um11.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um11.tpr -maxwarn 1
gmx_mpi mdrun -s um11.tpr -c after_um.gro 
cd ../
mkdir conf12
cp after_em.gro 2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj13.gro jz4.itp vnl1.itp um12.mdp um12_npt.mdp conf12
cd conf12
cp -r ../charmm36-jul2022.ff/ .
cp ../conf11/after_um.gro .
gmx_mpi grompp -f um12_npt.mdp -c traj13.gro -r traj13.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro 
gmx_mpi grompp -f um12.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um12.tpr -maxwarn 1
gmx_mpi mdrun -s um12.tpr -c after_um.gro
cd ../
mkdir conf13
cp after_em.gro 2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj14.gro jz4.itp vnl1.itp um13.mdp um13_npt.mdp conf13
cd conf13
cp -r ../charmm36-jul2022.ff/ .
cp ../conf12/after_um.gro .
gmx_mpi grompp -f um13_npt.mdp -c traj14.gro -r traj14.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro
gmx_mpi grompp -f um13.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um13.tpr -maxwarn 1
gmx_mpi mdrun -s um13.tpr -c after_um.gro
cd ../
mkdir conf14
cp after_em.gro 2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj15.gro jz4.itp vnl1.itp um14.mdp um14_npt.mdp conf14
cd conf14
cp -r ../charmm36-jul2022.ff/ .
cp ../conf13/after_um.gro .
gmx_mpi grompp -f um14_npt.mdp -c traj15.gro -r traj15.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro
gmx_mpi grompp -f um14.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um14.tpr -maxwarn 1
gmx_mpi mdrun -s um14.tpr -c after_um.gro
cd ../
mkdir conf15
cp after_em.gro 2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj16.gro jz4.itp vnl1.itp um15.mdp um15_npt.mdp conf15
cd conf15
cp -r ../charmm36-jul2022.ff/ .
cp ../conf14/after_um.gro .
gmx_mpi grompp -f um15_npt.mdp -c traj16.gro -r traj16.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro
gmx_mpi grompp -f um15.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um15.tpr -maxwarn 1
gmx_mpi mdrun -s um15.tpr -c after_um.gro
cd ../
mkdir conf16
cp after_em.gro 2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj17.gro jz4.itp vnl1.itp um16.mdp um16_npt.mdp conf16
cd conf16
cp -r ../charmm36-jul2022.ff/ .
cp ../conf15/after_um.gro .
gmx_mpi grompp -f um16_npt.mdp -c traj17.gro -r traj17.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro
gmx_mpi grompp -f um16.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um16.tpr -maxwarn 1
gmx_mpi mdrun -s um16.tpr -c after_um.gro
cd ../
mkdir conf17
cp after_em.gro 2index.ndx prot.top jz4.prm vnl1.prm posre.itp posre_Protein_chain_A.itp posre_Ion_chain_B.itp prot_Protein_chain_A.itp prot_Ion_chain_B.itp traj18.gro jz4.itp vnl1.itp um17.mdp um17_npt.mdp conf17
cd conf17
cp -r ../charmm36-jul2022.ff/ .
cp ../conf16/after_um.gro .
gmx_mpi grompp -f um17_npt.mdp -c traj18.gro -r traj18.gro -p prot.top -n 2index.ndx -o um_npt.tpr -maxwarn 1
gmx_mpi mdrun -s um_npt.tpr -c after_after_em.gro
gmx_mpi grompp -f um17.mdp -c after_after_em.gro -r after_after_em.gro -p prot.top -n 2index.ndx -o um17.tpr -maxwarn 1
gmx_mpi mdrun -s um17.tpr -c after_um.gro
cd ../
